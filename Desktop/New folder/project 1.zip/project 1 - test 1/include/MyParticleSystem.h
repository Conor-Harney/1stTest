#ifndef MYPARTICLESYSTEM_H
#define MYPARTICLESYSTEM_H

#include "Observer.h"
//#include "Rocket.h"
#include "Particle.h"
#include "Obstacle.h"

#include <Ogre.h>

// The constructor should create the particle system and 
// place it into the scenegraph.
// Provide other member functions/attributes as needed.


class MyParticleSystem : public Observer {
private:
	//Rocket *mRocket;
	Obstacle *mObstacle;
	
	Ogre::SceneNode *mParticleNode;
	Ogre::ParticleSystem *mSunParticle;

	

public:
	MyParticleSystem(Obstacle *pObstacle, Ogre::SceneManager *sceneMgr);	

	virtual void update();

};


#endif