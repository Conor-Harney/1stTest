#ifndef COLLISIONPARTICLE_H
#define COLLISIONPARTCILE_H

#include "BaseApplication.h"
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#include "../res/resource.h"
#endif

class CollisionParticle
{

private:
	Ogre::Vector3 m_position;/*!<To store the position of particle*/
	Ogre::Vector3 m_velocity;/*!<To store the velocity of particle*/
	double m_radius;/*!<radius of particle*/
	Ogre::SceneNode *m_object;/*!<For the Ogre SceneNode link*/

	Ogre::Vector3 m_startPos;/*!<Starting position of particle*/

	int m_lifeSpan;/*!<determines how long the particle remains visible */
	
public:

	CollisionParticle();
	CollisionParticle(Ogre::SceneNode* object, double radius, Ogre::Vector3 position, Ogre::Vector3 velocity);//!<Constructor method for the particle
	

	
	
	void init(Ogre::SceneNode* object, double radius, Ogre::Vector3 position);//!<This method initialises the particle, setting its sceneNode, dimentions, initial position and direction

	
	void update();//!<This method updates the particles, position by applying its velocity, velocity by applying gravity, and deincrements its lifespan.

	
	void reset(Ogre::Vector3 obstaclePos);//!<This method is called when the particle's lifespan is 0.This method sets the position of the particle is set to the contact point between the player and the rail and its lifespan is reset.

	Ogre::SceneNode* getNode();//!<returns the particle's sceneNode

	Ogre::Vector3 getPosition();//!<returns the particle's position

	Ogre::Vector3 getVelocity();//!<returns the particle's velocity

	void setPosition(Ogre::Vector3);//!<set's the particle's position to the passed value

	void setVelocity();//!<set's the particle's velocity to the passed value

	int GetLifeLeft();//!<returns the particle's lifeSpan

	void setVisibleTrue();//!<makes the particle invisible when the player is in mid air

	void setVisibleFalse();//!<makes the particle visible when the player hit's the rail again
};


#endif