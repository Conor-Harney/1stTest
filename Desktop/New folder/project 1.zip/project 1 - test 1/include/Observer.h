#ifndef OBSERVER_H
#define OBSERVER_H

// Forward reference
class Subject;

class Observer {
private: 
	Subject *mSubject;
public:
	virtual ~Observer();
	virtual void update() = 0;
	void setSubject(Subject *pSubject);
};

#include "Subject.h"

#endif