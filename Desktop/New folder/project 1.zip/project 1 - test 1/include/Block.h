#ifndef BLOCK_H
#define BLOCK_H
#include <vector>
#include <Ogre.h>
#include <algorithm>
#include <vector>
#include <iterator>
#include <iostream>
#include <math.h>

class Block{/*! block class - the world is made up of blocks  */

public:
	/**
	* each block holds a certin type which will effect 
	* the the entity that is on that block in a certin way.
	*/
	enum Block_Type{ null, streightRaill, curvedRail, gradientRail};
	static const int size = 50;/*!<every block has the same constant size*/
	Block(Ogre::Vector3 blockVecIn, Ogre::Vector3 posIn, Ogre::Vector3 directionIn);//!<constructor function
	void initilise(Ogre::SceneManager *sceneMan, Block::Block_Type typeOfBlock);//!<some parts of the block can ot be initilised in the constructor so an initilise method was needed
	double getSpeedMod();//!<every block has a speed modifier which will effect the accelleration of the player when it is on top of the bock
	Ogre::Vector3 getDirection();//!<get the direction to block is pointing in so the player can travle in that direction
	std::string blockName;/*!<name of the blocks entity*/
	float getTop();//!<the y position of the top of the block
	Block_Type blockType;/*!<the stored valiud of the blocks type*/
	void setObjectToCenter(Ogre::Vector3 * objPosPtr);//!<put the player in the center of the block while it is sliding along

protected:
	
	Ogre::Vector3 blockVec;/*!<the x, y and z number of the block */
	Ogre::Vector3 m_position;/*!< the position of the block*/
	
	
private:
	Ogre::Entity * mEntity;/*!<the blocks entity*/
	Ogre::SceneNode *mNode;/*!<the blocks scene node*/
	double mSpeedMod;/*!<the amount the palyer should accellerate when it is on top of this block*/
	Ogre::Vector3 mDirection;/*!<the directio in which the block is pointing*/
	Ogre::SceneManager *mSceneMgr;/*!<a pointer to the scene manager*/

};

#endif