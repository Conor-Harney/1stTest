#ifndef SUBJECT_H
#define SUBJECT_H

#include <list>
#include "Observer.h"

using std::list;

class Subject {
private:
	list<Observer *> mObservers;
public:
	virtual ~Subject();

	virtual void addObserver(Observer *pObserver);

	virtual void updateObservers();
};

#endif