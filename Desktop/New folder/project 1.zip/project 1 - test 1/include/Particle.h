#ifndef PARTICLE_H
#define PARTCILE_H

#include "BaseApplication.h"
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#include "../res/resource.h"
#endif

/*!Class for particles */
class Particle
{

private:
	Ogre::Vector3 m_position;/*!To store the position of missile*/
	Ogre::Vector3 m_velocity;/*!To store the velocity of missile*/
	double m_radius;
	Ogre::SceneNode *m_object;/*!For the Ogre SceneNode link*/

	float gravity;/*!rate that the particle falls at*/
	Ogre::Vector3 m_startPos;/*!initial position of the particle*/

	int m_lifeSpan;/*!How long the paricles last*/
	
public:
	/*!<
	* Constructor method for the particles
	*/
	Particle();
	Particle(Ogre::SceneNode* object, double radius, Ogre::Vector3 position, Ogre::Vector3 velocity);

	/*!<
	 This method initialises the particle, 
	 setting its sceneNode, dimentions, 
	 initial position and direction
	*/
	void init(Ogre::SceneNode* object, double radius, Ogre::Vector3 position, Ogre::Vector3 playerDir);

	/*!<
	 This method updates the particles, position
	 by applying its velocity, velocity by 
	 applying gravity, and deincrements its lifespan.
	*/
	void update();

	/*!<
	 This method is called when the particle's 
	 lifespan is 0.This method sets the position of 
	 the particle is set to the contact point between the 
	 player and the rail and its lifespan is reset.
	*/
	void reset(Ogre::Vector3 playerPos, Ogre::Vector3 playerDir);

	/*!<
	 returns the particle's sceneNode
	*/
	Ogre::SceneNode* getNode();

	/*!<
	 returns the particle's position
	*/
	Ogre::Vector3 getPosition();

	/*!<
	 returns the particle's velocity
	*/
	Ogre::Vector3 getVelocity();

	/*!<
	 set's the particle's position to the passed value
	*/
	void setPosition(Ogre::Vector3);

	/*!<
	 set's the particle's velocity to the passed value
	*/
	void setVelocity();

	/*!<
	 returns the particle's lifeSpan
	*/
	int GetLifeLeft();

	/*!<
	 makes the particle invisible when the player is in mid air
	*/
	void setVisibleTrue();

	/*!<
	 makes the particle visible when the player hit's the rail again
	*/
	void setVisibleFalse();
};


#endif