#ifndef __Obstacle_h_
#define __Obstacle_h_

#include "BaseApplication.h"
#include <Ogre.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using std::vector;

/*! The class of the obstacles which the must avoid */
class Obstacle
{
public:
	/*!<
	 Constructor method for the Obstacle class
	*/
	Obstacle(Ogre::SceneNode *object, Ogre::Vector3 pos, float width, float height, float depth, Ogre::Vector3 dir);

	/*!<
	 Destructor method for the Obstacle class
	*/
	~Obstacle(void);

	/*!<
	 IsHit checks whether collision has occurred 
	 between the player and the obstacle
	*/
	bool IsHit(Ogre::Vector3 playerPos, float playerWidth, float playerHeight, float playerDepth);

	/*!<
	 returns the position of the obstacle
	*/
	Ogre::Vector3 getPosition();

	/*!<
	 This method uses the obstacles direction 
	 and speed variables to update it position.
	 It also checks how far the object is from 
	 its initial position and changes its direction 
	 accordingly
	*/
	void update(double timePassed);

private:
	Ogre::Vector3 m_pos;/*!<current position of the obstacle */
	Ogre::Vector3 m_startPos;/*!<the initial position of the obstacle*/
	Ogre::Vector3 m_velocity;/*!<Rate of change of the obstacle's position in the 3 cardinal directions */
	Ogre::SceneNode *m_object;/*!<the sceneNode that the obstacle is attached to */
	
	float m_height;/*!<dimentions of the obstacle */
	float m_width;
	float m_depth;

	float m_isVisible;/*!<whether or not the obstacle is visible */

	float m_speed;/*!<speed of the obstacle */

	Ogre::Vector3 m_direction;/*!<direction that the obstacle is moving in */
};

#endif