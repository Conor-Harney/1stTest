#ifndef PLAYER_H
#define PLAYER_H
#include <Ogre.h>
#include "Block.h"
#include <string.h>
#include <string>
#include <vector>
#include <OgreCamera.h>
#include <OgreEntity.h>
#include <OgreLogManager.h>
#include <OgreRoot.h>
#include <OgreViewport.h>
#include <OgreSceneManager.h>
#include <OgreRenderWindow.h>
#include <OgreConfigFile.h>

#include <OISEvents.h>
#include <OISInputManager.h>
#include <OISKeyboard.h>
#include <OISMouse.h>

#include <SdkTrays.h>
#include <SdkCameraMan.h>

using std::vector;

class Player{/*!Player class - controles the little green disk that represents the player*/
public:
	Player(Ogre::Vector3 posIn, Ogre::SceneManager *sceneMan, vector<Block> & mapIn, float sizeIn);
	void reset();//!<reset the players position and velocity
	int m_score;	/*!<updated bassed on the amount of time the player is alive. */
	int m_deaths;	/*!<number of thies the palyer has fallen off the rail or has take enough damage*/
	double m_mass;	/*!<mass of the player: this was needed for some jumping equasions*/
	Ogre::Vector3 m_dimentions;	/*!<dimention of the player*/
	Ogre::Vector3 m_velocity;	/*!<velocity added to the players position*/
	Ogre::Vector3 m_acceleration;/*!<acceleration added to the velocity*/
	double m_speed;	/*!< a multiplyer for the velocity*/
	Ogre::Degree roll;/*!<the amount the player is tilted (unimplimented)*/
	void update(double timePassed);//!<the time that has passed since the last frame is passed in so the player can move at the same speed reguardless of fps
	Ogre::Vector3 getBlock();//!<check which block the player is currently inside of. the one below decides direction and speed incriment(", the one in front may be an obstacle" : method changed)
	void setJump();//!<use an impulse force to push the player upwards once. the update will handle the rest.
	vector<Block> & r_Map;/*!<a refference to the map of blocks. this is needed for getting the direction the player should travling in and their accelleration.*/
	Ogre::Vector3 overBlock();//!<The block the player is on top of.
	void setLean(std::string direction);//!<tilt the player in a specified direction to avoid some obstacles(unimplimentd) 
	void stopLean();//!<when the player lets go of the key to make the player lean to the side, the player should gradually tilt back to an upright position.
	Ogre::Quaternion getOrientation();//!<get the current orientation of the player
	bool jumping;/*!<if this is true, the player is in the middle of a jump. other actions can not be proformed.*/
	Ogre::Vector3 getDirection();//!<get the direction in the player is travling in in 3d vector form 
	Ogre::Vector3 GetPosition();//!<get the palyers position
	int blockOverId();//!<the id of the block the player is over
	void setPosition(Ogre::Vector3 posIn);//!<set the players position

	/*!side jumping vars*/
	bool m_fallenOff;		 /*!<if the player has fallen off the raill or not. if this is true, the player will either reset or the game will end*/
	bool m_isSideJumping;	 /*!<if true, the player is jumping to another rail*/
	float m_JumpPerSecond;	 /*!<the distance the player will cover in a second of jumping sidewards*/
	float m_AmountToSideJump;/*!<the distance the player has left to jump. This is set in the setJump method*/ 
	void changeRail(float timePassed);		//!<the method to update the player jumping to a diffirent rail
	void setSideJump(std::string jumpWhere);//!<start the player side jumping and set the amount (s)he has to jump.
	void HitObstacle();


private:
	 
	double getSpeedMod();///<get the speed from the block the player is on top of 
	float getOptimumRoll();///<get the amount that the player should be tilted to acheive the greatest speed(greater tilt on the corners will increas the players speed)(unimplimented)
	Ogre::Entity * mEntity;///< the players entity in the world
	Ogre::SceneNode *mNode;///< the players standard ogre scene node
	Ogre::SceneManager *mSceneMgr;///< a pointer to the scene manager needed to set up some variables.
	Ogre::Radian m_Angle;///< the angle the player is tilted
	Ogre::Vector3 m_jumpingIn;///< the direction the player is jumping in
	
	int vect32BlockID(Ogre::Vector3);///< after getting a blocks x, y and z number(not position), this method can be used to change that to the id of the block in the vector
	Ogre::Vector3 m_position;///<real position of the player
	Ogre::Vector3 m_startingPosition;///< the palyers starting position (used for reseting the player)
	float m_startingSpeed;///< players starting speed (used for reseting the player)
	bool checkOffRail();///<checks if the player has fallen off the rail

	
	float jumpforce;///< the force which the player jumps with
	void lean();///<method for the lean in a direction(unimplimented)
	bool leanBack;///<if the player needs to start leaning itself back to an upright position.
};
#endif