#include "Observer.h"

Observer::~Observer() {} 

void Observer::setSubject(Subject *pSubject) {
	mSubject = pSubject;
}
