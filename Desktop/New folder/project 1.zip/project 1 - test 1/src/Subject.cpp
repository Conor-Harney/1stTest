#include "Subject.h"

Subject::~Subject() {
	list<Observer *>::iterator iter = mObservers.begin();
	list<Observer *>::iterator endIter = mObservers.end();
	for (; iter != endIter; ++iter) {
		(*iter)->setSubject(0);
	}	
}

void Subject::addObserver(Observer *pObserver) {
	mObservers.push_back(pObserver);
}

void Subject::updateObservers() {
	list<Observer *>::iterator iter = mObservers.begin();
	list<Observer *>::iterator endIter = mObservers.end();
	for (; iter != endIter; ++iter) {
		(*iter)->update();
	}	
}
