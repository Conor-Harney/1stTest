#include "Obstacle.h"
#include <math.h>

Obstacle::Obstacle(Ogre::SceneNode *object, Ogre::Vector3 pos, float width, float height, float depth, Ogre::Vector3 dir):m_object(object), m_pos(pos), m_width(width), m_height(height), m_depth(depth), m_isVisible(true), m_speed(0.3), m_startPos(pos), m_direction(dir)
{

}

Obstacle::~Obstacle()
{
	delete(m_object);
}


bool Obstacle::IsHit(Ogre::Vector3 playerPos, float playerWidth, float playerHeight, float playerDepth)
{
	if(m_isVisible == true)
	{
		if(Ogre::Math::Sqrt((playerPos.x - m_pos.x)*(playerPos.x - m_pos.x) + (playerPos.y - m_pos.y)*(playerPos.y - m_pos.y)+(playerPos.z - m_pos.z)*(playerPos.z - m_pos.z))<playerWidth/2 + m_depth/2)
		{
			m_isVisible = false;
			return true;
		}

		else
			return false;
	}

	else
		return false;
}



void Obstacle::update(double timePassed){


	m_velocity.x = m_direction.x * m_speed;
	m_velocity.z = m_direction.z * m_speed;
	m_pos.x += m_velocity.x;
	m_pos.z += m_velocity.z;
	

	m_object->setPosition(m_pos);

	if(m_startPos.distance(m_pos)>15)
	{
		m_direction *= -1;
	}
	
}

Ogre::Vector3 Obstacle::getPosition()
{
	return m_pos;
}