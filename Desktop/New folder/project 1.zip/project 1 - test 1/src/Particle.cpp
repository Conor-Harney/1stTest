#include "Particle.h"

Particle::Particle()
{

}


Particle::Particle(Ogre::SceneNode* object, double radius, Ogre::Vector3 position, Ogre::Vector3 velocity):
				m_object(object), m_radius(radius), m_position(position), m_startPos(position),
				gravity(0.001)
{

}


void Particle::init(Ogre::SceneNode* object, double radius, Ogre::Vector3 position, Ogre::Vector3 playerDir)
{
	m_object = object;
	m_radius = radius;
	//m_velocity = velocity;
	m_position = position;

	m_position.y -= 12;

	gravity = 0.0001f;

	float xVel = (rand() % 10 + 1)/1;
	float yVel = (rand() % 10 + 1)/1;
	float zVel = (rand() % 10 + 1)/1;

	m_lifeSpan = rand() % 100 + 1;

	xVel /= 100;
	yVel /= 45;
	zVel /= 100;
	m_velocity = Ogre::Vector3(xVel, yVel, zVel);
}


void Particle::update()
{

	m_position +=m_velocity;
	m_velocity.y-=gravity;
	
	m_lifeSpan--;

	m_object->setPosition(m_position);

	
}


void Particle::reset(Ogre::Vector3 playerPos, Ogre::Vector3 playerDir)
{
	m_position = playerPos;

	m_position.y -= 12;

	gravity = 0.0001f;

	float xVel = (rand() % 10 + 1)/1;
	float yVel = (rand() % 10 + 1)/1;
	float zVel = (rand() % 10 + 1)/1;

	m_lifeSpan = rand() % 100 + 1;

	xVel /= 100;
	yVel /= 45;
	zVel /= 100;
	m_velocity = Ogre::Vector3(xVel, yVel, zVel);

	m_lifeSpan = rand() % 100 + 1;
}


Ogre::Vector3 Particle::getPosition()
{
	return m_position;
}


Ogre::Vector3 Particle::getVelocity()
{
	return m_velocity;
}


void Particle::setPosition(Ogre::Vector3 position)
{
	m_position = position;
}


void Particle::setVelocity()
{
	m_velocity.x *=-1;
	m_velocity.z *=-1;
}





int Particle::GetLifeLeft()
{
	return m_lifeSpan;
}

void Particle::setVisibleTrue()
{
	m_object->setVisible(true);
}

void Particle::setVisibleFalse()
{
	m_object->setVisible(false);
}