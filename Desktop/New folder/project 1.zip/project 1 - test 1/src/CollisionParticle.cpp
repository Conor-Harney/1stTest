#include "CollisionParticle.h"

CollisionParticle::CollisionParticle()
{

}
CollisionParticle::CollisionParticle(Ogre::SceneNode* object, double radius, Ogre::Vector3 position, Ogre::Vector3 velocity):
				m_object(object), m_radius(radius), m_position(position), m_startPos(position)
{

}

void CollisionParticle::init(Ogre::SceneNode* object, double radius, Ogre::Vector3 position)
{
	m_object = object;
	m_radius = radius;
	m_position = position;

	m_position.y -= 12;

	float xVel = (rand() % 10 + 1);
	float yVel = (rand() % 10 + 1);
	float zVel = (rand() % 10 + 1);

	m_lifeSpan = rand() % 100 + 1;

	xVel /= 5;
	yVel /= 5;
	zVel /= 5;

	m_velocity = Ogre::Vector3(xVel, yVel, zVel);

}

void CollisionParticle::update()
{
	m_position +=m_velocity;
	
	m_lifeSpan--;

	m_object->setPosition(m_position);

	if(m_lifeSpan<0)
		m_object->setVisible(false);
}

void CollisionParticle::reset(Ogre::Vector3 obstaclePos)
{
	m_position = obstaclePos;

	m_position.y -= 12;


	float xVel = (rand() % 10 + 1)/1;
	float yVel = (rand() % 10 + 1)/1;
	float zVel = (rand() % 10 + 1)/1;
	//
	m_lifeSpan = rand() % 100 + 1;

	xVel /= 100;
	yVel /= 45;
	zVel /= 100;
	m_velocity = Ogre::Vector3(xVel, yVel, zVel);

	m_lifeSpan = rand() % 100 + 1;

	m_object->setVisible(true);
}


Ogre::Vector3 CollisionParticle::getPosition()
{
	return m_position;
}

Ogre::Vector3 CollisionParticle::getVelocity()
{
	return m_velocity;
}

void CollisionParticle::setPosition(Ogre::Vector3 position)
{
	m_position = position;
}

void CollisionParticle::setVelocity()
{
	m_velocity.x *=-1;
	m_velocity.z *=-1;
	m_velocity.y *=-1;
}




int CollisionParticle::GetLifeLeft()
{
	return m_lifeSpan;
}

void CollisionParticle::setVisibleTrue()
{
	m_object->setVisible(true);
}

void CollisionParticle::setVisibleFalse()
{
	m_object->setVisible(false);
}