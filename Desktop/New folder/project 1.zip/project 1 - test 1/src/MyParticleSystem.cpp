#include "MyParticleSystem.h"

MyParticleSystem::MyParticleSystem(Obstacle *pObstacle, Ogre::SceneManager *sceneMgr) : mObstacle(pObstacle) {
	pObstacle->addObserver(this);
		
	mSunParticle = sceneMgr->createParticleSystem("smoking", "Examples/Smoke");
    mParticleNode = sceneMgr->getRootSceneNode()->createChildSceneNode("ParticleNode");	
		
    mParticleNode->attachObject(mSunParticle);
	mParticleNode->pitch( Degree( 180 ) );
	mParticleNode->setVisible( false ) ;
	mParticleNode->setPosition( 0, 0, 0 );
	
}
	
void MyParticleSystem::update() {
	if ( mRocket->isLaunched() ) {
		Real scaleFactor = 1.0f;
		mParticleNode->setVisible( true );
		// Display some convincing firey flickering effects based on
		//  fuel remaining.
		float fuelRemaining = mRocket->getFuel();

		// The scale factor for the particle effect is the fuel remaining / total fuel at launch.
		if ( fuelRemaining > 0 && scaleFactor > 0.1f ) {
			Real scaleFactor = fuelRemaining / 1000;
			mSunParticle->setDefaultDimensions( scaleFactor, scaleFactor );
			Vector3 rocketPos = mRocket->getPosition();
			mParticleNode->setPosition( rocketPos.x, rocketPos.y - 20, rocketPos.z );
		}
		else if ( fuelRemaining <= 0 ) {
			mParticleNode->setVisible( false );
		}
			
	}
}
